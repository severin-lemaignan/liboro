#! /bin/sh

aclocal
libtoolize -c -f
autoconf
