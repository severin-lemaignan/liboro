namespace oro {
	
class Position {
	public:
		double getX();
		double getY();
		double getZ();
	
};

}