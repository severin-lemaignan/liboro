/*
 * property.cpp
 *
 *  Created on: 10 mar. 2009
 *      Author: slemaign
 */

#include "oro.h"

using namespace std;

namespace oro {
	Property::Property(const std::string& name):_name(name){}
}
