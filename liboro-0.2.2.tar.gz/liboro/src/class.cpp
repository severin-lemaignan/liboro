/*
 * class.cpp
 *
 *  Created on: 10 mar. 2009
 *      Author: slemaign
 */

#include "oro.h"

using namespace std;

namespace oro {
	
Class::Class(const std::string& name): _name(name){}
	
}
